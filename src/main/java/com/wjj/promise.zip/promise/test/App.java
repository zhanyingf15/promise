package com.wjj.promise.test;

import com.wjj.promise.AbstractPromiseExecutor;
import com.wjj.promise.Promise;
import com.wjj.promise.RejectExecutor;
import com.wjj.promise.ResolveExecutor;
import com.wjj.promise.AbstractThenable;
import com.wjj.promise.then.OnFulfilledExecutor;

/**
 * @author wangjiajun
 * @date 2018/5/28 11:17
 */
public class App {
    public static void main(String[] args){
        Promise p = new Promise(new AbstractPromiseExecutor() {
            @Override
            public <T> T run(ResolveExecutor resolve, RejectExecutor reject) {
                Integer args = (Integer) this.getArgs();
                resolve.resolve(args*2);
                return null;
            }
        });
        new Promise(new AbstractPromiseExecutor(){
            @Override
            public Object run(ResolveExecutor resolve, RejectExecutor reject) {
                resolve.resolve(3);
                return null;
            }
        }).then(new AbstractThenable(){
            @Override
            public Object run() {
                return ((Integer)this.getLastPromiseResult())+1;
            }
        }).then(new OnFulfilledExecutor() {
            @Override
            public Object onFulfilled(Object resolvedData) {
                Integer i = ((Integer)resolvedData)+1;
                System.out.println(i);
                return i;
            }
        }).then(p)
        .then(new OnFulfilledExecutor() {
            @Override
            public Object onFulfilled(Object args) {
                System.out.println(args);
                return args;
            }
        });
    }
}
