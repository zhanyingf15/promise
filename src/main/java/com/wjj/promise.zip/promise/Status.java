package com.wjj.promise;

/**
 * @author wangjiajun
 */
public enum Status {
    PENDING,FULFILLED,REJECTED
}
