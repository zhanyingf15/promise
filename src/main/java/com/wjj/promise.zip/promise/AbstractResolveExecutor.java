package com.wjj.promise;

/**
 * @author wangjiajun
 * @date 2018/5/28 10:17
 */
public class AbstractResolveExecutor implements ResolveExecutor{
    private Promise promise;
    protected AbstractResolveExecutor(Promise promise){
        this.promise = promise;
    }
    @Override
    public <T> void resolve(final T args) {
        promise.transferStatus(Status.FULFILLED);
        promise.setResolvedData(args);
    }
}
