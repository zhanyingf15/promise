package com.wjj.promise;

import java.util.function.Function;

/**
 * @author wangjiajun
 * @date 2018/5/28 9:38
 */
public abstract class AbstractPromiseExecutor implements PromiseExecutor{
    private Object args;
    @Override
    public abstract <T> T run(ResolveExecutor resolve,RejectExecutor reject);

    public Object getArgs() {
        return args;
    }
    public void setArgs(Object args) {
        this.args = args;
    }
}
