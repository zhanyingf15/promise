package com.wjj.promise.then;

/**
 * @author wangjiajun
 * @date 2018/5/28 11:13
 */
public abstract class OnFulfilledExecutor {
    public abstract Object onFulfilled(Object resolvedData)throws Exception;
}
