package com.wjj.promise;

import com.wjj.promise.then.OnFulfilledExecutor;
import com.wjj.promise.then.OnRejectedExecutor;

/**
 * @author wangjiajun
 */
public class Promise extends AbstractThenable {
    private Status status = Status.PENDING;
    private AbstractPromiseExecutor promiseExecutor;
    private ResolveExecutor resolveExecutor;
    private RejectExecutor rejectExecutor;
    private Object resolvedData;
    private Object rejectedData;

    public Promise(AbstractPromiseExecutor promiseExecutor){
        this.promiseExecutor = promiseExecutor;
        this.resolveExecutor = new AbstractResolveExecutor(this);
        this.rejectExecutor = new AbstractRejectExecutor(this);
    }

    public Promise(Object data){
        this(data,true);
    }
    public Promise(Object data,boolean fulfilled){
        if(fulfilled){
            this.status = Status.FULFILLED;
            this.setResolvedData(data);
        }else{
            this.status = Status.REJECTED;
            this.setRejectedData(data);
        }

    }
    @Override
    final public  Object run(){
        final Object executeData = this.promiseExecutor.run(this.resolveExecutor,this.rejectExecutor);
        return executeData;
    }
    @Override
    public Promise then(final AbstractThenable thenable) {
        try{
            if(thenable==this){
                throw new RuntimeException("TypeError");
            }
            if(this.status.equals(Status.PENDING)){
                try {
                    final Object resolvedData = run();
                    //直接返回数据，没有调用resolve
                    if(this.status.equals(Status.PENDING)&&resolvedData!=null){
                        this.status = Status.FULFILLED;
                        this.setResolvedData(resolvedData);
                    }
                }catch (Exception e){
                    this.status = Status.REJECTED;
                    this.setRejectedData(e);
                }
            }
            thenable.setLastPromiseResult(this.getResolvedData());
            final Object thenResolved = thenable.run();
            if(thenResolved instanceof Promise){
                return (Promise)thenResolved;
            }else{
                return new Promise(thenResolved);
            }
        }catch (Exception e){
            return new Promise(e,false);
        }
    }
    @Override
    public Promise then(OnFulfilledExecutor onFulfilledExecutor){
        return then(onFulfilledExecutor,null);
    }
    @Override
    public Promise then(OnFulfilledExecutor onFulfilledExecutor, OnRejectedExecutor onRejectedExecutor){
        try {
            if(this.status.equals(Status.PENDING)){
                //执行具体方法产生的异常交给onRejectedExecutor处理
                try{
                    //执行具体的方法
                    final Object result = this.promiseExecutor.run(this.resolveExecutor,this.rejectExecutor);
                    //直接返回数据，没有调用resolve
                    if(this.status.equals(Status.PENDING)){
                        this.status = Status.FULFILLED;
                        this.setResolvedData(result);
                    }
                }catch (Exception e){
                    this.status = Status.REJECTED;
                    this.setRejectedData(e);
                }
            }
            if(this.status.equals(Status.FULFILLED)){
                Object r = onFulfilledExecutor.onFulfilled(this.getResolvedData());
                return new Promise(r);
            }else{
                if(onRejectedExecutor != null){
                    Object r = onRejectedExecutor.onRejected(this.getRejectedData());
                    return new Promise(r,false);
                }else{
                    return new Promise(this.getRejectedData(),false);
                }
            }
        }catch (Exception e){
            return new Promise(e,false);
        }

    }
    protected void transferStatus(Status status){
        if(this.status.equals(Status.FULFILLED)||this.status.equals(Status.REJECTED)){
            throw new RuntimeException("不允许转换");
        }
        this.status = status;
    }
    protected void setResolvedData(Object resolvedData){
        this.resolvedData = resolvedData;
    }
    protected void setRejectedData(Object rejectedData){
        this.rejectedData = rejectedData;
    }
    protected Object getResolvedData(){
        return this.resolvedData;
    }
    protected Object getRejectedData(){
        return this.rejectedData;
    }

}
