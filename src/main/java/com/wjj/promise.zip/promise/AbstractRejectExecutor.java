package com.wjj.promise;

/**
 * @author wangjiajun
 * @date 2018/5/28 10:17
 */
public class AbstractRejectExecutor implements RejectExecutor{
    private Promise promise;
    protected AbstractRejectExecutor(Promise promise){
        this.promise = promise;
    }
    @Override
    public <T> void reject(final T args) {
        promise.transferStatus(Status.REJECTED);
        promise.setRejectedData(args);
    }
}
