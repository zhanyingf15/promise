package com.wjj.promise;

/**
 * @author wangjiajun
 * @date 2018/5/28 13:53
 */
public interface PromiseExecutor {
    public <T> T run(ResolveExecutor resolve,RejectExecutor reject);
}
