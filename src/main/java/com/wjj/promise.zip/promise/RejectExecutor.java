package com.wjj.promise;

/**
 * @author wangjiajun
 * @date 2018/5/28 9:45
 */
public interface RejectExecutor {
    public <T> void reject(T args);
}
