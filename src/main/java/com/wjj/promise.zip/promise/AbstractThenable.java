package com.wjj.promise;

import com.wjj.promise.then.OnFulfilledExecutor;
import com.wjj.promise.then.OnRejectedExecutor;

/**
 * @author wangjiajun
 * @date 2018/5/28 10:45
 */
public abstract class AbstractThenable{

    private Object lastPromiseResult;

    public abstract Object run();

    public void setLastPromiseResult(Object result){
        this.lastPromiseResult = result;
    }
    public Object getLastPromiseResult(){
        return this.lastPromiseResult;
    }

    public AbstractThenable then(AbstractThenable thenable) {
        return null;
    }

    public AbstractThenable then(OnFulfilledExecutor onFulfilledExecutor) {
        return null;
    }
    public AbstractThenable then(OnFulfilledExecutor onFulfilledExecutor, OnRejectedExecutor onRejectedExecutor) {
        return null;
    }

}
