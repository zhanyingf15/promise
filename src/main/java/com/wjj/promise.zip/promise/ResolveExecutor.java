package com.wjj.promise;

/**
 * @author wangjiajun
 * @date 2018/5/28 9:45
 */
public interface ResolveExecutor{
    public <T> void resolve(T args);
}
